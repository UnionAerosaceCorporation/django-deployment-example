# Summary

Date : 2022-12-13 19:02:04

Directory d:\\UAC TRY-1\\static\\uac

Total : 16 files,  5739 codes, 109 comments, 839 blanks, all 6687 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| CSS | 16 | 5,739 | 109 | 839 | 6,687 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 16 | 5,739 | 109 | 839 | 6,687 |
| styles | 16 | 5,739 | 109 | 839 | 6,687 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)