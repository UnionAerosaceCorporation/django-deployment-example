# Details

Date : 2022-12-13 19:02:04

Directory d:\\UAC TRY-1\\static\\uac

Total : 16 files,  5739 codes, 109 comments, 839 blanks, all 6687 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [static/uac/styles/404.css](/static/uac/styles/404.css) | CSS | 60 | 0 | 5 | 65 |
| [static/uac/styles/about.css](/static/uac/styles/about.css) | CSS | 479 | 4 | 76 | 559 |
| [static/uac/styles/base.css](/static/uac/styles/base.css) | CSS | 174 | 2 | 38 | 214 |
| [static/uac/styles/goods.css](/static/uac/styles/goods.css) | CSS | 279 | 2 | 54 | 335 |
| [static/uac/styles/home.css](/static/uac/styles/home.css) | CSS | 635 | 5 | 81 | 721 |
| [static/uac/styles/more.css](/static/uac/styles/more.css) | CSS | 569 | 10 | 73 | 652 |
| [static/uac/styles/payment_success.css](/static/uac/styles/payment_success.css) | CSS | 654 | 0 | 19 | 673 |
| [static/uac/styles/reserve.css](/static/uac/styles/reserve.css) | CSS | 190 | 2 | 42 | 234 |
| [static/uac/styles/result1.css](/static/uac/styles/result1.css) | CSS | 699 | 63 | 86 | 848 |
| [static/uac/styles/select.css](/static/uac/styles/select.css) | CSS | 371 | 2 | 71 | 444 |
| [static/uac/styles/ships.css](/static/uac/styles/ships.css) | CSS | 486 | 8 | 68 | 562 |
| [static/uac/styles/success.css](/static/uac/styles/success.css) | CSS | 294 | 2 | 63 | 359 |
| [static/uac/styles/test1.css](/static/uac/styles/test1.css) | CSS | 257 | 2 | 58 | 317 |
| [static/uac/styles/tickets.css](/static/uac/styles/tickets.css) | CSS | 252 | 2 | 51 | 305 |
| [static/uac/styles/transport.css](/static/uac/styles/transport.css) | CSS | 0 | 0 | 1 | 1 |
| [static/uac/styles/xwing.css](/static/uac/styles/xwing.css) | CSS | 340 | 5 | 53 | 398 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)