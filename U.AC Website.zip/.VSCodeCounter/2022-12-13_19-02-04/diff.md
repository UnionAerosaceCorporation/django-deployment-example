# Diff Summary

Date : 2022-12-13 19:02:04

Directory d:\\UAC TRY-1\\static\\uac

Total : 27 files,  3738 codes, 90 comments, 307 blanks, all 4135 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| CSS | 16 | 5,739 | 109 | 839 | 6,687 |
| HTML | 11 | -2,001 | -19 | -532 | -2,552 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 27 | 3,738 | 90 | 307 | 4,135 |
| .. | 11 | -2,001 | -19 | -532 | -2,552 |
| ..\\.. | 11 | -2,001 | -19 | -532 | -2,552 |
| ..\\..\\templates | 11 | -2,001 | -19 | -532 | -2,552 |
| styles | 16 | 5,739 | 109 | 839 | 6,687 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)