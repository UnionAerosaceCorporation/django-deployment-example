# Details

Date : 2022-12-13 19:02:43

Directory d:\\UAC TRY-1\\base

Total : 11 files,  1030 codes, 529 comments, 205 blanks, all 1764 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [base/__init__.py](/base/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [base/admin.py](/base/admin.py) | Python | 8 | 1 | 1 | 10 |
| [base/apps.py](/base/apps.py) | Python | 5 | 0 | 3 | 8 |
| [base/forms.py](/base/forms.py) | Python | 42 | 0 | 8 | 50 |
| [base/models.py](/base/models.py) | Python | 123 | 1 | 33 | 157 |
| [base/templates/reserve.html](/base/templates/reserve.html) | HTML | 347 | 1 | 44 | 392 |
| [base/templates/result1.html](/base/templates/result1.html) | HTML | 242 | 1 | 52 | 295 |
| [base/templatetags/customfilter.py](/base/templatetags/customfilter.py) | Python | 14 | 0 | 5 | 19 |
| [base/tests.py](/base/tests.py) | Python | 1 | 1 | 2 | 4 |
| [base/urls.py](/base/urls.py) | Python | 32 | 0 | 11 | 43 |
| [base/views.py](/base/views.py) | Python | 216 | 524 | 45 | 785 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)