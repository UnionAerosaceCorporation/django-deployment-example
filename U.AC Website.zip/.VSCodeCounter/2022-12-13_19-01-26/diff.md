# Diff Summary

Date : 2022-12-13 19:01:26

Directory d:\\UAC TRY-1\\uac

Total : 219 files,  -66333 codes, -2559 comments, -16138 blanks, all -85030 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 5 | 121 | 260 | 66 | 447 |
| SCSS | 12 | -669 | -10 | -187 | -866 |
| JavaScript | 183 | -30,062 | -2,672 | -7,794 | -40,528 |
| CSS | 19 | -35,723 | -137 | -8,223 | -44,083 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 219 | -66,333 | -2,559 | -16,138 | -85,030 |
| .. | 214 | -66,454 | -2,819 | -16,204 | -85,477 |
| ..\\static | 214 | -66,454 | -2,819 | -16,204 | -85,477 |
| ..\\static\\assets | 214 | -66,454 | -2,819 | -16,204 | -85,477 |
| ..\\static\\assets\\bootstrap | 23 | -47,083 | -1,753 | -11,679 | -60,515 |
| ..\\static\\assets\\bootstrap\\css | 16 | -35,088 | -136 | -8,133 | -43,357 |
| ..\\static\\assets\\bootstrap\\js | 7 | -11,995 | -1,617 | -3,546 | -17,158 |
| ..\\static\\assets\\default | 3 | -1,752 | -1 | -101 | -1,854 |
| ..\\static\\assets\\default\\css | 1 | -156 | -1 | -29 | -186 |
| ..\\static\\assets\\default\\js | 2 | -1,596 | 0 | -72 | -1,668 |
| ..\\static\\assets\\select2 | 188 | -17,619 | -1,065 | -4,424 | -23,108 |
| ..\\static\\assets\\select2\\dist | 68 | -10,081 | -759 | -2,622 | -13,462 |
| ..\\static\\assets\\select2\\dist\\css | 2 | -479 | 0 | -61 | -540 |
| ..\\static\\assets\\select2\\dist\\js | 66 | -9,602 | -759 | -2,561 | -12,922 |
| ..\\static\\assets\\select2\\dist\\js\\i18n | 62 | -62 | -62 | -62 | -186 |
| ..\\static\\assets\\select2\\src | 120 | -7,538 | -306 | -1,802 | -9,646 |
| ..\\static\\assets\\select2\\src\\js | 108 | -6,869 | -296 | -1,615 | -8,780 |
| ..\\static\\assets\\select2\\src\\js\\select2 | 101 | -6,775 | -266 | -1,593 | -8,634 |
| ..\\static\\assets\\select2\\src\\js\\select2\\data | 9 | -648 | -19 | -227 | -894 |
| ..\\static\\assets\\select2\\src\\js\\select2\\dropdown | 11 | -554 | -15 | -188 | -757 |
| ..\\static\\assets\\select2\\src\\js\\select2\\i18n | 62 | -2,439 | -74 | -424 | -2,937 |
| ..\\static\\assets\\select2\\src\\js\\select2\\selection | 10 | -716 | -56 | -240 | -1,012 |
| ..\\static\\assets\\select2\\src\\scss | 12 | -669 | -10 | -187 | -866 |
| ..\\static\\assets\\select2\\src\\scss\\mixins | 1 | -7 | -5 | -2 | -14 |
| ..\\static\\assets\\select2\\src\\scss\\theme | 7 | -499 | -4 | -141 | -644 |
| ..\\static\\assets\\select2\\src\\scss\\theme\\classic | 4 | -246 | 0 | -81 | -327 |
| ..\\static\\assets\\select2\\src\\scss\\theme\\default | 3 | -253 | -4 | -60 | -317 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)