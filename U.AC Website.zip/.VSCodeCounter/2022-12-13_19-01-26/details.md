# Details

Date : 2022-12-13 19:01:26

Directory d:\\UAC TRY-1\\uac

Total : 5 files,  121 codes, 260 comments, 66 blanks, all 447 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [uac/__init__.py](/uac/__init__.py) | Python | 0 | 0 | 1 | 1 |
| [uac/asgi.py](/uac/asgi.py) | Python | 4 | 8 | 5 | 17 |
| [uac/settings.py](/uac/settings.py) | Python | 101 | 229 | 49 | 379 |
| [uac/urls.py](/uac/urls.py) | Python | 12 | 15 | 6 | 33 |
| [uac/wsgi.py](/uac/wsgi.py) | Python | 4 | 8 | 5 | 17 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)