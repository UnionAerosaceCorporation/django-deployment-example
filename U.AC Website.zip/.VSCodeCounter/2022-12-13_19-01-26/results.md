# Summary

Date : 2022-12-13 19:01:26

Directory d:\\UAC TRY-1\\uac

Total : 5 files,  121 codes, 260 comments, 66 blanks, all 447 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Python | 5 | 121 | 260 | 66 | 447 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 5 | 121 | 260 | 66 | 447 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)