# Diff Summary

Date : 2022-12-13 19:01:50

Directory d:\\UAC TRY-1\\templates

Total : 16 files,  1880 codes, -241 comments, 466 blanks, all 2105 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| HTML | 11 | 2,001 | 19 | 532 | 2,552 |
| Python | 5 | -121 | -260 | -66 | -447 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 16 | 1,880 | -241 | 466 | 2,105 |
| .. | 5 | -121 | -260 | -66 | -447 |
| ..\\uac | 5 | -121 | -260 | -66 | -447 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)