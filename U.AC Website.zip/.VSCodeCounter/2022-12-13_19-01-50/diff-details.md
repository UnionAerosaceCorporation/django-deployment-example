# Diff Details

Date : 2022-12-13 19:01:50

Directory d:\\UAC TRY-1\\templates

Total : 16 files,  1880 codes, -241 comments, 466 blanks, all 2105 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [templates/404.html](/templates/404.html) | HTML | 116 | 0 | 10 | 126 |
| [templates/about.html](/templates/about.html) | HTML | 244 | 0 | 73 | 317 |
| [templates/goods.html](/templates/goods.html) | HTML | 274 | 1 | 48 | 323 |
| [templates/home.html](/templates/home.html) | HTML | 302 | 3 | 89 | 394 |
| [templates/more.html](/templates/more.html) | HTML | 268 | 6 | 104 | 378 |
| [templates/payment_success.html](/templates/payment_success.html) | HTML | 52 | 0 | 19 | 71 |
| [templates/select.html](/templates/select.html) | HTML | 204 | 0 | 46 | 250 |
| [templates/ships.html](/templates/ships.html) | HTML | 225 | 5 | 76 | 306 |
| [templates/success.html](/templates/success.html) | HTML | 47 | 0 | 15 | 62 |
| [templates/transport.html](/templates/transport.html) | HTML | 75 | 0 | 7 | 82 |
| [templates/xwing.html](/templates/xwing.html) | HTML | 194 | 4 | 45 | 243 |
| [uac/__init__.py](/uac/__init__.py) | Python | 0 | 0 | -1 | -1 |
| [uac/asgi.py](/uac/asgi.py) | Python | -4 | -8 | -5 | -17 |
| [uac/settings.py](/uac/settings.py) | Python | -101 | -229 | -49 | -379 |
| [uac/urls.py](/uac/urls.py) | Python | -12 | -15 | -6 | -33 |
| [uac/wsgi.py](/uac/wsgi.py) | Python | -4 | -8 | -5 | -17 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details