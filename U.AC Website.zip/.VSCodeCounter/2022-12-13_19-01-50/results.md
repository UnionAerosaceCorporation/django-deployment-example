# Summary

Date : 2022-12-13 19:01:50

Directory d:\\UAC TRY-1\\templates

Total : 11 files,  2001 codes, 19 comments, 532 blanks, all 2552 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| HTML | 11 | 2,001 | 19 | 532 | 2,552 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 11 | 2,001 | 19 | 532 | 2,552 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)