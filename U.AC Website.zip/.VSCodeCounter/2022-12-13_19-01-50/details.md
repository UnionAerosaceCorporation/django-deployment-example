# Details

Date : 2022-12-13 19:01:50

Directory d:\\UAC TRY-1\\templates

Total : 11 files,  2001 codes, 19 comments, 532 blanks, all 2552 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [templates/404.html](/templates/404.html) | HTML | 116 | 0 | 10 | 126 |
| [templates/about.html](/templates/about.html) | HTML | 244 | 0 | 73 | 317 |
| [templates/goods.html](/templates/goods.html) | HTML | 274 | 1 | 48 | 323 |
| [templates/home.html](/templates/home.html) | HTML | 302 | 3 | 89 | 394 |
| [templates/more.html](/templates/more.html) | HTML | 268 | 6 | 104 | 378 |
| [templates/payment_success.html](/templates/payment_success.html) | HTML | 52 | 0 | 19 | 71 |
| [templates/select.html](/templates/select.html) | HTML | 204 | 0 | 46 | 250 |
| [templates/ships.html](/templates/ships.html) | HTML | 225 | 5 | 76 | 306 |
| [templates/success.html](/templates/success.html) | HTML | 47 | 0 | 15 | 62 |
| [templates/transport.html](/templates/transport.html) | HTML | 75 | 0 | 7 | 82 |
| [templates/xwing.html](/templates/xwing.html) | HTML | 194 | 4 | 45 | 243 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)