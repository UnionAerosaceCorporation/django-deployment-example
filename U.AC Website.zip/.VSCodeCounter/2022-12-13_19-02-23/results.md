# Summary

Date : 2022-12-13 19:02:23

Directory d:\\UAC TRY-1\\base

Total : 11 files,  1030 codes, 529 comments, 205 blanks, all 1764 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| HTML | 2 | 589 | 2 | 96 | 687 |
| Python | 9 | 441 | 527 | 109 | 1,077 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 11 | 1,030 | 529 | 205 | 1,764 |
| templates | 2 | 589 | 2 | 96 | 687 |
| templatetags | 1 | 14 | 0 | 5 | 19 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)