# Diff Summary

Date : 2022-12-13 19:02:23

Directory d:\\UAC TRY-1\\base

Total : 27 files,  -4709 codes, 420 comments, -634 blanks, all -4923 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| HTML | 2 | 589 | 2 | 96 | 687 |
| Python | 9 | 441 | 527 | 109 | 1,077 |
| CSS | 16 | -5,739 | -109 | -839 | -6,687 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 27 | -4,709 | 420 | -634 | -4,923 |
| .. | 16 | -5,739 | -109 | -839 | -6,687 |
| ..\\static | 16 | -5,739 | -109 | -839 | -6,687 |
| ..\\static\\uac | 16 | -5,739 | -109 | -839 | -6,687 |
| ..\\static\\uac\\styles | 16 | -5,739 | -109 | -839 | -6,687 |
| templates | 2 | 589 | 2 | 96 | 687 |
| templatetags | 1 | 14 | 0 | 5 | 19 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)